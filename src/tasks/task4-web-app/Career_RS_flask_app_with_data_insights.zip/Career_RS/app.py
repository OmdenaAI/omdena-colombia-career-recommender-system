import flask
import pickle
import pandas as pd
import numpy as np

from tensorflow.keras.models import load_model

from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import QuantileTransformer

qt = QuantileTransformer(output_distribution='normal')


# Loading Model
model = load_model("models/model_career_RS.h5")

ss = StandardScaler()


# class_names = {0: 'BUSINESS',
#  1: 'SPORTS AND PHYSICAL TRAIN',
#  2: 'ENGINEERING',
#  3: 'AGRONOMIC, LIVESTOCK ENGINEERING',
#  4: 'HUMANITIES AND SOCIAL SCIENCE',
#  5: 'MATH AND PHYSICAL SCIENCES',
#  6: 'NUTRITION AND DIETETICS',
#  7: 'HEALTH & MEDICINE',
#  8: 'ARTS AND DESIGN',
#  9: 'BIOLOGICAL SCIENCE',
#  10: 'AGRICULTURAL, FOREST ENGINEERING',
#  11: 'PLASTIC ARTS, VISUAL ARTS',
#  12: 'PHISICS'}


class_names = ['BUSINESS',
 'SPORTS AND PHYSICAL TRAIN',
 'ENGINEERING',
 'AGRONOMIC, LIVESTOCK ENGINEERING',
 'HUMANITIES AND SOCIAL SCIENCE',
 'MATH AND PHYSICAL SCIENCES',
 'NUTRITION AND DIETETICS',
 'HEALTH & MEDICINE',
 'ARTS AND DESIGN',
 'BIOLOGICAL SCIENCE',
 'AGRICULTURAL, FOREST ENGINEERING',
 'PLASTIC ARTS, VISUAL ARTS',
 'PHISICS']



# routes 

app = flask.Flask(__name__, template_folder='templates')
@app.route('/')
def main():
    return (flask.render_template('index.html'))

@app.route('/report1')
def report():
    return (flask.render_template('report1_major.html'))

@app.route('/report2')
def jointreport():
    return (flask.render_template('report2_minor.html'))


@app.route("/career_rs", methods=['GET', 'POST'])
def Career_Recommendation():
    
    if flask.request.method == 'GET':
        return (flask.render_template('Career_RS.html'))
    
    if flask.request.method =='POST':
        
        #get Scores input
        
        score_language       =  int(flask.request.form['language'])
        score_mathematics    =  int(flask.request.form['mathematic'])
        score_biology        =  int(flask.request.form['biology'])
        score_chemistry      =  int(flask.request.form['chemistry'])
        score_physics        =  int(flask.request.form['physics'])
        score_social_science =  int(flask.request.form['social_science'])
        score_philosophy     =  int(flask.request.form['philosophy'])
        score_english        =  int(flask.request.form['english'])

        
        #create original output dict
        output_dict= dict()
        output_dict['score_language'] = score_language
        output_dict['score_mathematics'] = score_mathematics
        output_dict['score_biology'] = score_biology
        output_dict['score_chemistry']=score_chemistry
        output_dict['score_physics'] = score_physics
        output_dict['score_social_science'] = score_social_science
        output_dict['score_philosophy'] = score_philosophy
        output_dict['score_english'] = score_english
        
        # x = np.zeros(8)
    
        # x[0] = score_language
        # x[1] = score_mathematics
        # x[2] = score_biology
        # x[3] = score_chemistry
        # x[4] = score_physics
        # x[5] = score_social_science
        # x[6] = score_philosophy
        # x[7] = score_english

        # xx= x 

        X = [score_language,score_mathematics,score_biology,score_chemistry,score_physics,score_social_science,score_philosophy,score_english]
        #xx = qt.fit_transform(xx)
        #xx= xx.reshape(-1,1)
        print('------this is array data to predict-------')
        print('X = '+str(X))
        print('------------------------------------------')

        #pred = model.predict([x])[0]

        probs = model.predict([X])
        pred_class = np.argmax(probs)

        pred_class_name = class_names[pred_class]
        proba1 = int(probs[0][pred_class]*100)
        # proba2 = int(probs[1][pred_class]*100)
        # proba3 = int(probs[2][pred_class]*100)
        # proba4 = int(probs[3][pred_class]*100)
        # proba5 = int(probs[4][pred_class]*100)


        result = [pred_class_name,proba1]#,proba2,proba3,proba4,proba5]
        res = f'Top Career based on the Career_Recommendation System is {pred_class_name} with probability of {int(probs[0][pred_class]*100)}%'
        #print(res)
        
        # if pred==1:
        #     res = '🎊🎊Congratulations! your Loan Application has been Approved!🎊🎊'
        # else:
        #         res = '😔😔Unfortunatly your Loan Application has been Denied😔😔'
        

 
        #render form again and add prediction
        return flask.render_template('Career_RS.html',original_input=output_dict, result=result,)


        
        
        
      
if __name__ == '__main__':
    app.run(debug=True)